==Instructions==

No special instructions - just unzip and use the .NET assembly as a reference in Visual studio. Ensure the
respective Assimp DLL is in the same directory as the .NET assembly or provide a custom path to the unmanaged DLL in your app. Enjoy!

As a new user, your starting point should be the AssimpImporter class. This allows you to import models, and from
there the documentation should be able to guide you through the model data structure.